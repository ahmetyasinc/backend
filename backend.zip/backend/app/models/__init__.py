from .user import User  # Eğer `user.py` içinde tanımladıysan
